
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup_video')
    .setDescription('Thiết lập kênh để nhận yêu cầu chuyển đổi văn bản thành video 🎥')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Kênh để nhận yêu cầu chuyển đổi video 📺')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, { loadConfig, saveConfig, logToChannel }) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng lệnh này! 🔒', ephemeral: true });
      await logToChannel(`⚠️ ${interaction.user.tag} cố gắng sử dụng /setup_video nhưng không có quyền admin`);
      return;
    }

    const channel = interaction.options.getChannel('channel');
    const config = await loadConfig();
    config.videoChannelId = channel.id;
    await saveConfig(config);
    await interaction.reply(`✅ Đã thiết lập kênh video: ${channel.name} 🎥`);
    await logToChannel(`🌟 Đã thiết lập kênh video: ${channel.name} bởi ${interaction.user.tag}`);
  },

  async handleMessage(message, { loadConfig, saveConfig, logToChannel }) {
    const config = await loadConfig();
    
    // Kiểm tra xem có phải kênh video không
    if (message.channelId !== config.videoChannelId) {
      return;
    }

    // Không xử lý tin nhắn của bot
    if (message.author.id === message.client.user.id) {
      return;
    }

    // Không xử lý lệnh slash
    if (message.content.startsWith('/')) {
      return;
    }

    // Kiểm tra quyền admin
    if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
      await message.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng tính năng này! 🔒', ephemeral: true });
      await logToChannel(`⚠️ ${message.author.tag} cố gắng chuyển đổi video nhưng không có quyền admin trong kênh ${message.channel.name}`);
      return;
    }

    const text = message.content.trim();
    if (!text) {
      return;
    }

    try {
      // Thông báo bắt đầu chuyển đổi
      const processingMsg = await message.reply('⏳ Đang xử lý yêu cầu... Đang chuyển đổi văn bản thành video 🎬');
      
      // Log bắt đầu
      await logToChannel(`🌟 Bắt đầu chuyển đổi văn bản thành video bởi ${message.author.tag} trong kênh ${message.channel.name}. Nội dung: "${text.substring(0, 100)}..."`);

      // Kiểm tra API key
      if (!process.env.PIXVERSE_API_KEY) {
        const errorMsg = '🚫 Lỗi hệ thống: Chưa thiết lập PIXVERSE_API_KEY trong file .env. Vui lòng liên hệ admin để cập nhật API key!';
        await processingMsg.edit(errorMsg);
        await logToChannel(`🚫 Lỗi: Thiếu PIXVERSE_API_KEY. Vui lòng thêm API key vào file .env và khởi động lại bot.`);
        return;
      }

      // Gọi API Pixverse (endpoint giả định, cần thay thế bằng endpoint thực tế)
      let apiResponse;
      try {
        apiResponse = await axios.post(
          'https://api.pixverse.ai/v1/video/generate', // Thay thế bằng endpoint thực tế
          {
            prompt: text,
            style: 'realistic',
            model: 'free'
          },
          {
            headers: {
              'Authorization': `Bearer ${process.env.PIXVERSE_API_KEY}`,
              'Content-Type': 'application/json'
            },
            timeout: 120000 // 2 phút timeout
          }
        );
      } catch (apiError) {
        let errorDetail = apiError.message;
        if (apiError.response) {
          errorDetail = `Status: ${apiError.response.status}, Message: ${apiError.response.data?.message || 'Không có chi tiết'}`;
        } else if (apiError.request) {
          errorDetail = 'Không thể kết nối đến server Pixverse';
        }
        
        const errorMsg = `🚫 Lỗi khi gọi API Pixverse: ${errorDetail}`;
        await processingMsg.edit(errorMsg);
        await logToChannel(`🚫 Lỗi API Pixverse bởi ${message.author.tag}: ${errorDetail}. Request: ${JSON.stringify({ prompt: text })}`);
        return;
      }

      // Kiểm tra response từ API
      if (!apiResponse.data || !apiResponse.data.video_url) {
        const errorMsg = '🚫 API Pixverse trả về dữ liệu không hợp lệ. Không tìm thấy URL video.';
        await processingMsg.edit(errorMsg);
        await logToChannel(`🚫 Lỗi response API bởi ${message.author.tag}: Response không chứa video_url. Response: ${JSON.stringify(apiResponse.data)}`);
        return;
      }

      const videoUrl = apiResponse.data.video_url;
      const videoFileName = `video_${Date.now()}.mp4`;
      const videoFilePath = path.join(__dirname, videoFileName);

      // Tải video từ URL
      let videoBuffer;
      try {
        const videoResponse = await axios({
          method: 'GET',
          url: videoUrl,
          responseType: 'arraybuffer',
          timeout: 60000 // 1 phút để tải video
        });

        videoBuffer = Buffer.from(videoResponse.data);
        await fs.writeFile(videoFilePath, videoBuffer);
      } catch (downloadError) {
        let downloadDetail = downloadError.message;
        if (downloadError.response) {
          downloadDetail = `Status: ${downloadError.response.status}`;
        }
        const errorMsg = `🚫 Lỗi khi tải video: ${downloadDetail}`;
        await processingMsg.edit(errorMsg);
        await logToChannel(`🚫 Lỗi tải video bởi ${message.author.tag}: ${downloadDetail}. URL: ${videoUrl}`);
        return;
      }

      // Kiểm tra kích thước file
      const fileStats = await fs.stat(videoFilePath);
      const fileSizeMB = (fileStats.size / (1024 * 1024)).toFixed(2);

      if (fileSizeMB > 8) {
        const errorMsg = `🚫 File video quá lớn (${fileSizeMB} MB). Discord chỉ hỗ trợ tối đa 8MB.`;
        await processingMsg.edit(errorMsg);
        await fs.unlink(videoFilePath).catch(() => {});
        await logToChannel(`🚫 Lỗi kích thước file bởi ${message.author.tag}: ${fileSizeMB} MB > 8MB`);
        return;
      }

      // Gửi video lên kênh
      const endTime = Date.now();
      const processingTime = ((endTime - processingMsg.createdTimestamp) / 1000).toFixed(1);

      await processingMsg.edit({
        content: `🎉🌟 Video đã được tạo thành công! 🎥\n` +
                 `📜 **Văn bản gốc:** ${text}\n` +
                 `🎨 **Phong cách:** Realistic\n` +
                 `📏 **Dung lượng:** ${fileSizeMB} MB\n` +
                 `⏱️ **Thời gian xử lý:** ${processingTime} giây\n` +
                 `👤 **Người tạo:** ${message.author}\n` +
                 `Cảm ơn bạn đã sử dụng bot! 🙌✨`
      });

      const sentMessage = await message.channel.send({
        files: [{
          attachment: videoFilePath,
          name: videoFileName
        }]
      });

      // Log thành công chi tiết
      await logToChannel(`✅ Thành công: Video được tạo từ văn bản "${text.substring(0, 50)}..." bởi ${message.author.tag} trong kênh ${message.channel.name}. ` +
                        `Kích thước: ${fileSizeMB} MB, Thời gian: ${processingTime}s, ID tin nhắn: ${sentMessage.id}`);

      // Xóa file tạm
      await fs.unlink(videoFilePath).catch(err => {
        logToChannel(`⚠️ Cảnh báo: Không thể xóa file tạm ${videoFilePath}: ${err.message}`);
      });

    } catch (error) {
      const errorMsg = `🚫 Đã xảy ra lỗi không xác định: ${error.message}`;
      await message.reply(errorMsg).catch(() => {});
      await logToChannel(`🚫 Lỗi không xác định bởi ${message.author.tag} trong kênh ${message.channel.name}: ${error.stack || error.message}. ` +
                        `Nội dung yêu cầu: "${text}"`);
    }
  }
};
