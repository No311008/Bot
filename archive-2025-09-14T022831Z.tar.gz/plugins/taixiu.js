const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ChannelType, InteractionResponseFlags } = require('discord.js');
const fs = require('fs').promises;

// Cấu hình mặc định
const CONFIG = {
    taixiuChannelId: null,
    logChannelId: null,
    currencyName: 'xu',
    defaultBalance: 200000,
    minBet: 20000,
    maxBet: 10000000000,
    sessionDuration: 60000,
    bettingDeadline: 55000
};

// File lưu trữ dữ liệu
const PLAYER_DATA_FILE = 'player_data.json';
const HISTORY_FILE = 'taixiu_history.json';

// Emoji
const EMOJIS = {
    dice: '🎲',
    win: '🎉',
    lose: '😢',
    info: 'ℹ️',
    settings: '⚙️',
    admin: '🔧',
    money: '💰',
    help: '❓',
    test: '🧪',
    transfer: '💸',
    history: '📜',
    topWin: '🏆',
    clock: '⏰'
};

// Biến lưu thông tin phiên
const sessionState = {
    currentSession: null,
    sessionCounter: 0,
    countdownInterval: null,
    sessionMessage: null
};

// Tải dữ liệu người chơi
let playerData = {};
async function loadPlayerData() {
    try {
        if (await fs.access(PLAYER_DATA_FILE).then(() => true).catch(() => false)) {
            playerData = JSON.parse(await fs.readFile(PLAYER_DATA_FILE, 'utf8'));
            console.log(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [INFO] Đã tải dữ liệu người chơi từ ${PLAYER_DATA_FILE}`);
        }
    } catch (error) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi đọc file dữ liệu người chơi: ${error.message}`);
    }
}

// Tải lịch sử cầu và số phiên
let history = [];
async function loadHistory() {
    try {
        if (await fs.access(HISTORY_FILE).then(() => true).catch(() => false)) {
            const historyData = JSON.parse(await fs.readFile(HISTORY_FILE, 'utf8'));
            history = historyData.history || [];
            sessionState.sessionCounter = historyData.sessionCounter || 0;
            console.log(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [INFO] Đã tải lịch sử cầu và số phiên từ ${HISTORY_FILE}`);
        }
    } catch (error) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi đọc file lịch sử: ${error.message}`);
    }
}

// Hàm lưu dữ liệu người chơi
async function savePlayerData() {
    try {
        await fs.writeFile(PLAYER_DATA_FILE, JSON.stringify(playerData, null, 4));
        console.log(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [INFO] Đã lưu dữ liệu người chơi vào ${PLAYER_DATA_FILE}`);
    } catch (error) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi lưu file dữ liệu người chơi: ${error.message}`);
    }
}

// Hàm lưu lịch sử và số phiên
async function saveHistory() {
    try {
        await fs.writeFile(HISTORY_FILE, JSON.stringify({ history, sessionCounter: sessionState.sessionCounter }, null, 4));
        console.log(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [INFO] Đã lưu lịch sử cầu và số phiên vào ${HISTORY_FILE}`);
    } catch (error) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi lưu file lịch sử: ${error.message}`);
    }
}

// Hàm lấy số dư
function getBalance(userId) {
    if (!playerData[userId]) {
        playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
        savePlayerData();
    }
    return playerData[userId].balance;
}

// Hàm cập nhật số dư
function updateBalance(userId, amount) {
    if (!playerData[userId]) {
        playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
    }
    playerData[userId].balance += amount;
    if (amount !== 0) savePlayerData();
}

// Hàm đặt số dư
function setBalance(userId, amount) {
    if (!playerData[userId]) {
        playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
    }
    playerData[userId].balance = amount;
    savePlayerData();
}

// Hàm reset số dư
function resetBalance(userId) {
    if (!playerData[userId]) {
        playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
    } else {
        playerData[userId].balance = CONFIG.defaultBalance;
        playerData[userId].bets = {};
    }
    savePlayerData();
}

// Hàm hiển thị lịch sử cầu
function displayHistory() {
    const recentHistory = history.slice(-9);
    return recentHistory.length > 0
        ? recentHistory.map(h => `Phiên #${h.sessionId}: ${h.result}`).join('\n')
        : 'Chưa có lịch sử cầu';
}

// Hàm gửi log (chỉ ghi vào console)
async function logToChannel(message) {
    console.log(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [INFO] ${message}`);
}

// Hàm bắt đầu phiên
async function startSession(client) {
    if (sessionState.currentSession) return;
    sessionState.sessionCounter++;
    sessionState.currentSession = { startTime: Date.now(), bets: {}, sessionId: sessionState.sessionCounter };
    await logToChannel(`Phiên tài xỉu #${sessionState.sessionCounter} bắt đầu. Thời gian: ${CONFIG.sessionDuration / 1000} giây.`);

    if (CONFIG.taixiuChannelId) {
        const channel = client.channels.cache.get(CONFIG.taixiuChannelId);
        if (channel && channel.isTextBased()) {
            try {
                sessionState.sessionMessage = await channel.send(`${EMOJIS.dice} **Phiên tài xỉu #${sessionState.sessionCounter} bắt đầu!** Gửi \`!taixiu cược tài <số tiền>\` hoặc \`!taixiu cược xỉu <số tiền>\` trong ${CONFIG.bettingDeadline / 1000}s. Tối thiểu ${CONFIG.minBet.toLocaleString()}, tối đa ${CONFIG.maxBet.toLocaleString()} ${CONFIG.currencyName}.`);
                // Đếm ngược
                setTimeout(async () => {
                    let timeLeft = 11;
                    sessionState.countdownInterval = setInterval(async () => {
                        if (!sessionState.currentSession || timeLeft <= 1) {
                            clearInterval(sessionState.countdownInterval);
                            sessionState.countdownInterval = null;
                            return;
                        }
                        try {
                            await channel.send(`${EMOJIS.clock} **Phiên #${sessionState.currentSession.sessionId}: Còn ${timeLeft - 1} giây** đến khi kết thúc!`);
                        } catch (error) {
                            console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi gửi đếm ngược phiên #${sessionState.currentSession.sessionId}: ${error.message}`);
                            await logToChannel(`Lỗi gửi đếm ngược phiên #${sessionState.currentSession.sessionId}: ${error.message}`);
                        }
                        timeLeft--;
                    }, 1000);
                }, CONFIG.sessionDuration - 11000);
                // Kết thúc phiên
                setTimeout(async () => {
                    if (sessionState.currentSession) {
                        await endSession(client, null);
                    }
                }, CONFIG.sessionDuration + 1000);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi gửi thông báo phiên #${sessionState.sessionCounter}: ${error.message}`);
                await logToChannel(`Lỗi gửi thông báo phiên #${sessionState.sessionCounter}: ${error.message}`);
            }
        } else {
            console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Kênh tài xỉu không hợp lệ hoặc bot thiếu quyền truy cập kênh ${CONFIG.taixiuChannelId}`);
            await logToChannel(`Kênh tài xỉu không hợp lệ hoặc bot thiếu quyền truy cập kênh ${CONFIG.taixiuChannelId}`);
        }
    } else {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Chưa thiết lập kênh tài xỉu (taixiuChannelId)`);
        await logToChannel(`Chưa thiết lập kênh tài xỉu (taixiuChannelId)`);
    }
}

// Hàm kết thúc phiên
async function endSession(client, dice = null) {
    if (!sessionState.currentSession) return;
    const sessionId = sessionState.currentSession.sessionId;

    if (!CONFIG.taixiuChannelId) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Chưa thiết lập kênh tài xỉu (taixiuChannelId)`);
        await logToChannel(`Chưa thiết lập kênh tài xỉu (taixiuChannelId)`);
        sessionState.currentSession = null;
        sessionState.sessionMessage = null;
        if (sessionState.countdownInterval) {
            clearInterval(sessionState.countdownInterval);
            sessionState.countdownInterval = null;
        }
        await startSession(client);
        return;
    }

    const channel = client.channels.cache.get(CONFIG.taixiuChannelId);
    if (!channel || !channel.isTextBased()) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Kênh tài xỉu ${CONFIG.taixiuChannelId} không hợp lệ hoặc không phải kênh văn bản`);
        await logToChannel(`Kênh tài xỉu ${CONFIG.taixiuChannelId} không hợp lệ hoặc không phải kênh văn bản`);
        sessionState.currentSession = null;
        sessionState.sessionMessage = null;
        if (sessionState.countdownInterval) {
            clearInterval(sessionState.countdownInterval);
            sessionState.countdownInterval = null;
        }
        await startSession(client);
        return;
    }

    const botPermissions = channel.permissionsFor(client.user);
    if (!botPermissions.has([PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.EmbedLinks])) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Bot thiếu quyền SendMessages hoặc EmbedLinks trong kênh ${CONFIG.taixiuChannelId}`);
        await logToChannel(`Bot thiếu quyền SendMessages hoặc EmbedLinks trong kênh ${CONFIG.taixiuChannelId}`);
        sessionState.currentSession = null;
        sessionState.sessionMessage = null;
        if (sessionState.countdownInterval) {
            clearInterval(sessionState.countdownInterval);
            sessionState.countdownInterval = null;
        }
        await startSession(client);
        return;
    }

    if (Object.keys(sessionState.currentSession.bets).length === 0) {
        try {
            await channel.send(`${EMOJIS.dice} Không có người chơi tham gia phiên #${sessionId}, phiên đã được reset.`);
            await logToChannel(`Không có người chơi tham gia phiên #${sessionId}, phiên đã được reset.`);
            sessionState.sessionCounter--;
        } catch (error) {
            console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi gửi thông báo reset phiên #${sessionId}: ${error.message}`);
            await logToChannel(`Lỗi gửi thông báo reset phiên #${sessionId}: ${error.message}`);
        }
        sessionState.currentSession = null;
        sessionState.sessionMessage = null;
        if (sessionState.countdownInterval) {
            clearInterval(sessionState.countdownInterval);
            sessionState.countdownInterval = null;
        }
        await startSession(client);
        return;
    }

    const resultDice = dice || Array.from({ length: 3 }, () => Math.floor(Math.random() * 6) + 1);
    const total = resultDice.reduce((a, b) => a + b, 0);
    const result = total >= 11 ? 'Tài' : 'Xỉu';

    history.push({ sessionId, dice: resultDice, total, result });
    if (history.length > 10) history.shift();
    await saveHistory();

    const embed = new EmbedBuilder()
        .setTitle(`${EMOJIS.dice} Kết quả tài xỉu phiên #${sessionId}`)
        .setColor('#FFD700')
        .addFields(
            { name: 'Xúc xắc', value: `${resultDice[0]} + ${resultDice[1]} + ${resultDice[2]} = ${total}`, inline: false },
            { name: 'Kết quả', value: `**${result}**`, inline: false },
            { name: `${EMOJIS.history} Lịch sử cầu (9 cầu trước + hiện tại)`, value: displayHistory(), inline: false }
        );

    const winners = [];
    const losers = [];
    let topWinner = { userId: null, amount: 0 };
    for (const [userId, userData] of Object.entries(playerData)) {
        for (const [betId, bet] of Object.entries(userData.bets || {})) {
            if (bet.choice.toLowerCase() === result.toLowerCase()) {
                const winnings = bet.amount * 2;
                updateBalance(userId, winnings);
                winners.push(`<@${userId}> thắng ${winnings.toLocaleString()} ${CONFIG.currencyName}`);
                if (winnings > topWinner.amount) {
                    topWinner = { userId, amount: winnings };
                }
            } else {
                losers.push(`<@${userId}> thua ${bet.amount.toLocaleString()} ${CONFIG.currencyName}`);
            }
        }
        userData.bets = {};
    }

    await savePlayerData();

    if (winners.length) {
        embed.addFields({ name: `${EMOJIS.win} Người thắng`, value: winners.join('\n'), inline: false });
        if (topWinner.userId) {
            embed.addFields({ name: `${EMOJIS.topWin} Người thắng nhiều nhất`, value: `<@${topWinner.userId}> thắng ${topWinner.amount.toLocaleString()} ${CONFIG.currencyName}`, inline: false });
        }
    }
    if (losers.length) {
        embed.addFields({ name: `${EMOJIS.lose} Người thua`, value: losers.join('\n'), inline: false });
    }

    try {
        await channel.send({ embeds: [embed] });
        await logToChannel(`Kết thúc phiên #${sessionId}. Kết quả: ${result} (${resultDice.join('+')}=${total}).`);
    } catch (error) {
        console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi gửi kết quả phiên #${sessionId}: ${error.message}`);
        await logToChannel(`Lỗi gửi kết quả phiên #${sessionId}: ${error.message}`);
    }

    sessionState.currentSession = null;
    sessionState.sessionMessage = null;
    if (sessionState.countdownInterval) {
        clearInterval(sessionState.countdownInterval);
        sessionState.countdownInterval = null;
    }
    await startSession(client);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('taixiu')
        .setDescription('Plugin tài xỉu giống Minecraft')
        .addSubcommand(subcommand =>
            subcommand
                .setName('tro_giup')
                .setDescription('Hiển thị hướng dẫn chơi tài xỉu'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('cau_hinh')
                .setDescription('Cấu hình plugin tài xỉu (quản trị viên)')
                .addStringOption(option => option.setName('key').setDescription('Khóa cấu hình').setRequired(true).addChoices(
                    { name: 'Kênh chơi tài xỉu', value: 'taixiuChannelId' },
                    { name: 'Kênh log', value: 'logChannelId' },
                    { name: 'Tên tiền tệ', value: 'currencyName' },
                    { name: 'Số dư mặc định', value: 'defaultBalance' },
                    { name: 'Cược tối thiểu', value: 'minBet' },
                    { name: 'Cược tối đa', value: 'maxBet' }
                ))
                .addChannelOption(option => option.setName('kenh').setDescription('Chọn kênh').addChannelTypes(ChannelType.GuildText))
                .addStringOption(option => option.setName('gia_tri').setDescription('Giá trị cấu hình')))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tai_xiu')
                .setDescription('Cược tài xỉu')
                .addStringOption(option => option.setName('lua_chon').setDescription('Chọn tài hoặc xỉu').setRequired(true).addChoices(
                    { name: 'Tài', value: 'tài' },
                    { name: 'Xỉu', value: 'xỉu' }
                ))
                .addIntegerOption(option => option.setName('so_tien').setDescription('Số tiền cược').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('ket_qua')
                .setDescription('Công bố kết quả và bắt đầu phiên mới (quản trị viên)'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('so_du')
                .setDescription('Xem số dư hiện tại'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('nap_tien')
                .setDescription('Nạp tiền cho người chơi (quản trị viên)')
                .addUserOption(option => option.setName('nguoi_choi').setDescription('Người chơi').setRequired(true))
                .addIntegerOption(option => option.setName('so_tien').setDescription('Số tiền').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('rut_tien')
                .setDescription('Rút tiền từ người chơi (quản trị viên)')
                .addUserOption(option => option.setName('nguoi_choi').setDescription('Người chơi').setRequired(true))
                .addIntegerOption(option => option.setName('so_tien').setDescription('Số tiền').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('pay')
                .setDescription('Chuyển tiền cho người chơi khác')
                .addUserOption(option => option.setName('nguoi_nhan').setDescription('Người nhận').setRequired(true))
                .addIntegerOption(option => option.setName('so_tien').setDescription('Số tiền chuyển').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset_tien')
                .setDescription('Reset số dư của người chơi (quản trị viên)')
                .addUserOption(option => option.setName('nguoi_choi').setDescription('Người chơi').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset_phien')
                .setDescription('Reset lịch sử cầu và số phiên (quản trị viên)'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('set_ket_qua')
                .setDescription('Đặt kết quả tài xỉu (quản trị viên)')
                .addIntegerOption(option => option.setName('dice1').setDescription('Xúc xắc 1 (1-6)').setRequired(true))
                .addIntegerOption(option => option.setName('dice2').setDescription('Xúc xắc 2 (1-6)').setRequired(true))
                .addIntegerOption(option => option.setName('dice3').setDescription('Xúc xắc 3 (1-6)').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('set_tien')
                .setDescription('Đặt số dư cụ thể cho người chơi (quản trị viên)')
                .addUserOption(option => option.setName('nguoi_choi').setDescription('Người chơi').setRequired(true))
                .addIntegerOption(option => option.setName('so_tien').setDescription('Số tiền').setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('test')
                .setDescription('Kiểm tra hoạt động của plugin (quản trị viên)')),

    async execute(interaction) {
        const client = interaction.client;

        // Tải dữ liệu khi khởi động
        if (Object.keys(playerData).length === 0) await loadPlayerData();
        if (history.length === 0) await loadHistory();

        // Xử lý lệnh chat !taixiu
        if (module.exports.handleMessage) {
            client.off('messageCreate', module.exports.handleMessage);
        }
        module.exports.handleMessage = async message => {
            if (message.author.bot || message.channelId !== CONFIG.taixiuChannelId) return;
            if (!message.content.startsWith('!taixiu cược')) return;

            if (!sessionState.currentSession) {
                await startSession(client);
            }

            const elapsedTime = Date.now() - sessionState.currentSession.startTime;
            if (elapsedTime > CONFIG.bettingDeadline) {
                await message.reply(`${EMOJIS.info} Đã hết thời gian đặt cược (${CONFIG.bettingDeadline / 1000}s đầu)!`);
                return;
            }

            const args = message.content.split(' ').slice(2);
            if (args.length < 2) {
                await message.reply(`${EMOJIS.info} Vui lòng nhập: \`!taixiu cược <tài|xỉu> <số tiền>\``);
                return;
            }

            const choice = args[0].toLowerCase();
            if (!['tài', 'xỉu'].includes(choice)) {
                await message.reply(`${EMOJIS.info} Vui lòng chọn 'tài' hoặc 'xỉu'!`);
                return;
            }

            let amount;
            try {
                const amountStr = args[1].replace(/[^0-9]/g, '');
                amount = parseInt(amountStr);
                if (isNaN(amount) || amount < CONFIG.minBet || amount > CONFIG.maxBet) {
                    throw new Error(`Số tiền cược không hợp lệ: ${args[1]}`);
                }
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi xử lý số tiền cược từ ${message.author.tag}: ${error.message}`);
                await logToChannel(`Lỗi xử lý số tiền cược từ ${message.author.tag}: ${error.message}`);
                await message.reply(`${EMOJIS.info} Số tiền cược phải là số từ ${CONFIG.minBet.toLocaleString()} đến ${CONFIG.maxBet.toLocaleString()} ${CONFIG.currencyName}!`);
                return;
            }

            const userId = message.author.id;
            const balance = getBalance(userId);
            if (balance < amount) {
                await message.reply(`${EMOJIS.lose} Bạn không đủ tiền! Số dư hiện tại: ${balance.toLocaleString()} ${CONFIG.currencyName}`);
                return;
            }

            try {
                if (!playerData[userId]) {
                    playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
                }
                const betId = `chat_${Date.now()}`;
                playerData[userId].bets[betId] = { choice, amount };
                updateBalance(userId, -amount);
                sessionState.currentSession.bets[userId] = playerData[userId].bets;

                const timeLeft = Math.max(0, Math.floor((CONFIG.sessionDuration - (Date.now() - sessionState.currentSession.startTime)) / 1000));
                await message.reply(`${EMOJIS.dice} ${message.author} đã cược ${amount.toLocaleString()} ${CONFIG.currencyName} vào **${choice}** (Phiên #${sessionState.currentSession.sessionId}). ${EMOJIS.clock} Còn ${timeLeft} giây.`);
                await logToChannel(`${message.author.tag} đã cược ${amount.toLocaleString()} ${CONFIG.currencyName} vào ${choice} (Phiên #${sessionState.currentSession.sessionId}). Còn ${timeLeft} giây.`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi lưu cược từ ${message.author.tag}: ${error.message}`);
                await logToChannel(`Lỗi lưu cược từ ${message.author.tag}: ${error.message}`);
                await message.reply(`${EMOJIS.info} Đã xảy ra lỗi khi đặt cược! Vui lòng thử lại.`);
            }
        };
        client.on('messageCreate', module.exports.handleMessage);

        // Xử lý lệnh slash
        const isAdmin = interaction.member.permissions.has(PermissionsBitField.Flags.Administrator);
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'tro_giup') {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.help} Hướng dẫn chơi tài xỉu`)
                .setColor('#00FF00')
                .setDescription(`
                    **Cách chơi:**
                    - ${EMOJIS.dice} Gửi \`!taixiu cược tài <số tiền>\` hoặc \`!taixiu cược xỉu <số tiền>\` trong kênh <#${CONFIG.taixiuChannelId || 'chưa thiết lập'}> (tối thiểu ${CONFIG.minBet.toLocaleString()}, tối đa ${CONFIG.maxBet.toLocaleString()} ${CONFIG.currencyName}). Ví dụ: \`!taixiu cược tài 50000\`
                    - ${EMOJIS.dice} **/taixiu tai_xiu <tài|xỉu> <số tiền>** - Cược qua lệnh slash
                    - ${EMOJIS.money} **/taixiu so_du** - Xem số dư ${CONFIG.currencyName}
                    - ${EMOJIS.transfer} **/taixiu pay <người nhận> <số tiền>** - Chuyển ${CONFIG.currencyName}. Ví dụ: \`/taixiu pay @user 1000\`

                    **Lệnh admin:**
                    - ${EMOJIS.settings} **/taixiu cau_hinh <khóa> [giá trị]** - Cấu hình kênh, tiền tệ, v.v.
                    - ${EMOJIS.dice} **/taixiu ket_qua** - Công bố kết quả và bắt đầu phiên mới
                    - ${EMOJIS.dice} **/taixiu set_ket_qua <dice1> <dice2> <dice3>** - Đặt kết quả
                    - ${EMOJIS.money} **/taixiu nap_tien <người chơi> <số tiền>** - Nạp tiền
                    - ${EMOJIS.money} **/taixiu rut_tien <người chơi> <số tiền>** - Rút tiền
                    - ${EMOJIS.money} **/taixiu set_tien <người chơi> <số tiền>** - Đặt số dư
                    - ${EMOJIS.admin} **/taixiu reset_tien <người chơi>** - Reset số dư
                    - ${EMOJIS.admin} **/taixiu reset_phien** - Reset lịch sử cầu và số phiên
                    - ${EMOJIS.test} **/taixiu test** - Kiểm tra plugin

                    **Thông tin:**
                    - Phiên kéo dài ${CONFIG.sessionDuration / 1000}s, cược trong ${CONFIG.bettingDeadline / 1000}s đầu.
                    - Kết quả tự động công bố sau 60s, phiên mới bắt đầu ngay sau đó.
                    - Nếu không có người chơi, phiên sẽ reset.
                    - Chỉ chơi trong kênh <#${CONFIG.taixiuChannelId || 'chưa thiết lập'}>.
                `);
            try {
                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu tro_giup: ${error.message}`);
                await logToChannel(`Lỗi /taixiu tro_giup: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi hiển thị hướng dẫn! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'cau_hinh') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const key = interaction.options.getString('key');
            const channel = interaction.options.getChannel('kenh');
            const value = interaction.options.getString('gia_tri');

            try {
                if (key === 'taixiuChannelId' || key === 'logChannelId') {
                    if (!channel) {
                        return interaction.reply({ content: `${EMOJIS.info} Vui lòng chọn một kênh!`, flags: InteractionResponseFlags.Ephemeral });
                    }
                    if (channel.type !== ChannelType.GuildText) {
                        return interaction.reply({ content: `${EMOJIS.info} Kênh phải là kênh văn bản!`, flags: InteractionResponseFlags.Ephemeral });
                    }
                    CONFIG[key] = channel.id;
                    await interaction.reply(`${EMOJIS.settings} Đã thiết lập ${key === 'taixiuChannelId' ? 'kênh chơi tài xỉu' : 'kênh log'} thành ${channel}`);
                    await logToChannel(`Đã thiết lập ${key} thành ${channel.name} bởi ${interaction.user.tag}`);
                } else {
                    if (!value) {
                        return interaction.reply({ content: `${EMOJIS.info} Vui lòng cung cấp giá trị cho ${key}!`, flags: InteractionResponseFlags.Ephemeral });
                    }
                    CONFIG[key] = isNaN(value) ? value : parseInt(value);
                    await interaction.reply(`${EMOJIS.settings} Đã cập nhật ${key} thành ${value}`);
                    await logToChannel(`Đã cập nhật cấu hình ${key} thành ${value} bởi ${interaction.user.tag}`);
                }
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu cau_hinh: ${error.message}`);
                await logToChannel(`Lỗi /taixiu cau_hinh: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi cấu hình! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'tai_xiu') {
            if (CONFIG.taixiuChannelId && interaction.channelId !== CONFIG.taixiuChannelId) {
                return interaction.reply({ content: `${EMOJIS.info} Vui lòng chơi tài xỉu trong kênh <#${CONFIG.taixiuChannelId}>!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (!sessionState.currentSession) {
                await startSession(client);
            }

            const elapsedTime = Date.now() - sessionState.currentSession.startTime;
            if (elapsedTime > CONFIG.bettingDeadline) {
                return interaction.reply({ content: `${EMOJIS.info} Đã hết thời gian đặt cược (${CONFIG.bettingDeadline / 1000}s đầu)!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const choice = interaction.options.getString('lua_chon').toLowerCase();
            const amount = interaction.options.getInteger('so_tien');

            if (!['tài', 'xỉu'].includes(choice)) {
                return interaction.reply({ content: `${EMOJIS.info} Vui lòng chọn 'tài' hoặc 'xỉu'!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (amount < CONFIG.minBet || amount > CONFIG.maxBet) {
                return interaction.reply({ content: `${EMOJIS.info} Số tiền cược phải từ ${CONFIG.minBet.toLocaleString()} đến ${CONFIG.maxBet.toLocaleString()} ${CONFIG.currencyName}!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const userId = interaction.user.id;
            const balance = getBalance(userId);

            if (balance < amount) {
                return interaction.reply({ content: `${EMOJIS.lose} Bạn không đủ tiền! Số dư hiện tại: ${balance.toLocaleString()} ${CONFIG.currencyName}`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                if (!playerData[userId]) {
                    playerData[userId] = { balance: CONFIG.defaultBalance, bets: {} };
                }
                playerData[userId].bets[interaction.id] = { choice, amount };
                updateBalance(userId, -amount);
                sessionState.currentSession.bets[userId] = playerData[userId].bets;

                const timeLeft = Math.max(0, Math.floor((CONFIG.sessionDuration - elapsedTime) / 1000));
                await interaction.reply(`${EMOJIS.dice} ${interaction.user} đã cược ${amount.toLocaleString()} ${CONFIG.currencyName} vào **${choice}** (Phiên #${sessionState.currentSession.sessionId}). ${EMOJIS.clock} Còn ${timeLeft} giây.`);
                await logToChannel(`${interaction.user.tag} đã cược ${amount.toLocaleString()} ${CONFIG.currencyName} vào ${choice} (Phiên #${sessionState.currentSession.sessionId}). Còn ${timeLeft} giây.`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu tai_xiu: ${error.message}`);
                await logToChannel(`Lỗi /taixiu tai_xiu (Phiên #${sessionState.currentSession.sessionId}): ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi đặt cược! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'ket_qua') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (!CONFIG.taixiuChannelId) {
                return interaction.reply({ content: `${EMOJIS.info} Chưa thiết lập kênh tài xỉu!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (!sessionState.currentSession) {
                return interaction.reply({ content: `${EMOJIS.info} Hiện không có phiên tài xỉu nào đang diễn ra!`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                await endSession(client);
                await interaction.reply({ content: `${EMOJIS.dice} Đã công bố kết quả phiên #${sessionState.sessionCounter}! Phiên mới đã bắt đầu.` });
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu ket_qua: ${error.message}`);
                await logToChannel(`Lỗi /taixiu ket_qua (Phiên #${sessionState.sessionCounter}): ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi công bố kết quả! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'so_du') {
            const balance = getBalance(interaction.user.id);
            try {
                await interaction.reply(`${EMOJIS.money} ${interaction.user}, bạn hiện có **${balance.toLocaleString()} ${CONFIG.currencyName}**.`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu so_du: ${error.message}`);
                await logToChannel(`Lỗi /taixiu so_du: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi xem số dư! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'nap_tien') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const target = interaction.options.getUser('nguoi_choi');
            const amount = interaction.options.getInteger('so_tien');

            if (amount <= 0) {
                return interaction.reply({ content: `${EMOJIS.info} Số tiền phải lớn hơn 0!`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                updateBalance(target.id, amount);
                await interaction.reply(`${EMOJIS.money} Đã nạp ${amount.toLocaleString()} ${CONFIG.currencyName} cho ${target}`);
                await logToChannel(`Đã nạp ${amount.toLocaleString()} ${CONFIG.currencyName} cho ${target.tag} bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu nap_tien: ${error.message}`);
                await logToChannel(`Lỗi /taixiu nap_tien: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi nạp tiền! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'rut_tien') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const target = interaction.options.getUser('nguoi_choi');
            const amount = interaction.options.getInteger('so_tien');

            if (amount <= 0) {
                return interaction.reply({ content: `${EMOJIS.info} Số tiền phải lớn hơn 0!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const balance = getBalance(target.id);
            if (balance < amount) {
                return interaction.reply({ content: `${EMOJIS.lose} ${target} không đủ tiền! Số dư hiện tại: ${balance.toLocaleString()} ${CONFIG.currencyName}`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                updateBalance(target.id, -amount);
                await interaction.reply(`${EMOJIS.money} Đã rút ${amount.toLocaleString()} ${CONFIG.currencyName} từ ${target}`);
                await logToChannel(`Đã rút ${amount.toLocaleString()} ${CONFIG.currencyName} từ ${target.tag} bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu rut_tien: ${error.message}`);
                await logToChannel(`Lỗi /taixiu rut_tien: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi rút tiền! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'pay') {
            const recipient = interaction.options.getUser('nguoi_nhan');
            const amount = interaction.options.getInteger('so_tien');
            const userId = interaction.user.id;

            if (recipient.id === userId) {
                return interaction.reply({ content: `${EMOJIS.info} Bạn không thể chuyển tiền cho chính mình!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (amount <= 0) {
                return interaction.reply({ content: `${EMOJIS.info} Số tiền chuyển phải lớn hơn 0!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const balance = getBalance(userId);
            if (balance < amount) {
                return interaction.reply({ content: `${EMOJIS.lose} Bạn không đủ tiền! Số dư hiện tại: ${balance.toLocaleString()} ${CONFIG.currencyName}`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                updateBalance(userId, -amount);
                updateBalance(recipient.id, amount);
                await interaction.reply(`${EMOJIS.transfer} ${interaction.user} đã chuyển ${amount.toLocaleString()} ${CONFIG.currencyName} cho ${recipient}`);
                await logToChannel(`Đã chuyển ${amount.toLocaleString()} ${CONFIG.currencyName} từ ${interaction.user.tag} cho ${recipient.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu pay: ${error.message}`);
                await logToChannel(`Lỗi /taixiu pay: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi chuyển tiền! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'reset_tien') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const target = interaction.options.getUser('nguoi_choi');
            try {
                resetBalance(target.id);
                await interaction.reply(`${EMOJIS.admin} Đã reset số dư của ${target} về ${CONFIG.defaultBalance.toLocaleString()} ${CONFIG.currencyName}`);
                await logToChannel(`Đã reset số dư của ${target.tag} về ${CONFIG.defaultBalance.toLocaleString()} ${CONFIG.currencyName} bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu reset_tien: ${error.message}`);
                await logToChannel(`Lỗi /taixiu reset_tien: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi reset số dư! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'reset_phien') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                history = [];
                sessionState.sessionCounter = 0;
                await saveHistory();
                if (sessionState.currentSession) {
                    sessionState.currentSession = null;
                    sessionState.sessionMessage = null;
                    if (sessionState.countdownInterval) {
                        clearInterval(sessionState.countdownInterval);
                        sessionState.countdownInterval = null;
                    }
                    await logToChannel(`Đã reset phiên tài xỉu hiện tại bởi ${interaction.user.tag}`);
                }
                await interaction.reply(`${EMOJIS.admin} Đã reset lịch sử cầu và số phiên!`);
                await logToChannel(`Đã reset lịch sử cầu và số phiên bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu reset_phien: ${error.message}`);
                await logToChannel(`Lỗi /taixiu reset_phien: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi reset phiên! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'set_ket_qua') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (!CONFIG.taixiuChannelId) {
                return interaction.reply({ content: `${EMOJIS.info} Chưa thiết lập kênh tài xỉu!`, flags: InteractionResponseFlags.Ephemeral });
            }

            if (!sessionState.currentSession) {
                return interaction.reply({ content: `${EMOJIS.info} Hiện không có phiên tài xỉu nào đang diễn ra!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const dice1 = interaction.options.getInteger('dice1');
            const dice2 = interaction.options.getInteger('dice2');
            const dice3 = interaction.options.getInteger('dice3');

            if ([dice1, dice2, dice3].some(d => d < 1 || d > 6)) {
                return interaction.reply({ content: `${EMOJIS.info} Giá trị xúc xắc phải từ 1 đến 6!`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                await endSession(client, [dice1, dice2, dice3]);
                await interaction.reply({ content: `${EMOJIS.dice} Đã đặt kết quả phiên #${sessionState.sessionCounter}! Phiên mới đã bắt đầu.` });
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu set_ket_qua: ${error.message}`);
                await logToChannel(`Lỗi /taixiu set_ket_qua (Phiên #${sessionState.sessionCounter}): ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi đặt kết quả! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'set_tien') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const target = interaction.options.getUser('nguoi_choi');
            const amount = interaction.options.getInteger('so_tien');

            if (amount < 0) {
                return interaction.reply({ content: `${EMOJIS.info} Số tiền không được âm!`, flags: InteractionResponseFlags.Ephemeral });
            }

            try {
                setBalance(target.id, amount);
                await interaction.reply(`${EMOJIS.money} Đã đặt số dư của ${target} thành ${amount.toLocaleString()} ${CONFIG.currencyName}`);
                await logToChannel(`Đã đặt số dư của ${target.tag} thành ${amount.toLocaleString()} ${CONFIG.currencyName} bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu set_tien: ${error.message}`);
                await logToChannel(`Lỗi /taixiu set_tien: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi đặt số dư! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }

        else if (subcommand === 'test') {
            if (!isAdmin) {
                return interaction.reply({ content: `${EMOJIS.info} Chỉ quản trị viên có thể sử dụng lệnh này!`, flags: InteractionResponseFlags.Ephemeral });
            }

            const testData = {
                'test_user_1': { balance: 1000, bets: { 'test_bet_1': { choice: 'tài', amount: 100 } } },
                'test_user_2': { balance: 1000, bets: { 'test_bet_2': { choice: 'xỉu', amount: 150 } } }
            };

            const dice = Array.from({ length: 3 }, () => Math.floor(Math.random() * 6) + 1);
            const total = dice.reduce((a, b) => a + b, 0);
            const result = total >= 11 ? 'Tài' : 'Xỉu';

            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.test} Kết quả kiểm tra plugin tài xỉu`)
                .setColor('#00BFFF')
                .setDescription(`
                    **Cấu hình hiện tại:**
                    - Kênh tài xỉu: ${CONFIG.taixiuChannelId ? `<#${CONFIG.taixiuChannelId}>` : 'Chưa thiết lập'}
                    - Kênh log: ${CONFIG.logChannelId ? `<#${CONFIG.logChannelId}>` : 'Chưa thiết lập'}
                    - Tiền tệ: ${CONFIG.currencyName}
                    - Số dư mặc định: ${CONFIG.defaultBalance.toLocaleString()}
                    - Cược tối thiểu: ${CONFIG.minBet.toLocaleString()}
                    - Cược tối đa: ${CONFIG.maxBet.toLocaleString()}
                    - Thời gian phiên: ${CONFIG.sessionDuration / 1000}s
                    - Phiên hiện tại: #${sessionState.sessionCounter}

                    **Kết quả mô phỏng:**
                    - Xúc xắc: ${dice[0]} + ${dice[1]} + ${dice[2]} = ${total}
                    - Kết quả: **${result}**
                    - Lịch sử cầu: ${displayHistory()}

                    **Trạng thái:** Plugin hoạt động bình thường!
                `);

            const winners = [];
            const losers = [];
            let topWinner = { userId: null, amount: 0 };
            for (const [userId, userData] of Object.entries(testData)) {
                for (const [betId, bet] of Object.entries(userData.bets)) {
                    if (bet.choice.toLowerCase() === result.toLowerCase()) {
                        const winnings = bet.amount * 2;
                        winners.push(`Người chơi thử ${userId} thắng ${winnings.toLocaleString()} ${CONFIG.currencyName}`);
                        if (winnings > topWinner.amount) {
                            topWinner = { userId, amount: winnings };
                        }
                    } else {
                        losers.push(`Người chơi thử ${userId} thua ${bet.amount.toLocaleString()} ${CONFIG.currencyName}`);
                    }
                }
            }

            if (winners.length) {
                embed.addFields({ name: `${EMOJIS.win} Người thắng (Mô phỏng)`, value: winners.join('\n'), inline: false });
                if (topWinner.userId) {
                    embed.addFields({ name: `${EMOJIS.topWin} Người thắng nhiều nhất (Mô phỏng)`, value: `Người chơi thử ${topWinner.userId} thắng ${topWinner.amount.toLocaleString()} ${CONFIG.currencyName}`, inline: false });
                }
            }
            if (losers.length) {
                embed.addFields({ name: `${EMOJIS.lose} Người thua (Mô phỏng)`, value: losers.join('\n'), inline: false });
            }

            try {
                await interaction.reply({ embeds: [embed] });
                await logToChannel(`Đã thực hiện kiểm tra plugin bởi ${interaction.user.tag}`);
            } catch (error) {
                console.error(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}] [ERROR] Lỗi /taixiu test: ${error.message}`);
                await logToChannel(`Lỗi /taixiu test: ${error.message}`);
                await interaction.reply({ content: `${EMOJIS.info} Đã xảy ra lỗi khi kiểm tra plugin! Vui lòng thử lại.`, flags: InteractionResponseFlags.Ephemeral });
            }
        }
    },
};