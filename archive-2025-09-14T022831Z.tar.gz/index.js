const { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes, PermissionFlagsBits } = require('discord.js');
const Groq = require('groq-sdk');
const fs = require('fs').promises;
const yaml = require('js-yaml');
const path = require('path');
require('dotenv').config();
const axios = require('axios');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions
  ]
});

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
const CONFIG_FILE = path.join(__dirname, 'config.json');
const TEST_FILE_PATH = path.join(__dirname, 'test.txt');
const PLUGINS_DIR = path.join(__dirname, 'plugins');
const ENV_FILE = path.join(__dirname, '.env');

// Giới hạn ký tự cho mỗi đoạn khi chia nhỏ
const CHUNK_SIZE = 5000;
const MAX_CONTENT_LENGTH = 10000;
const MAX_PROMPT_LENGTH = 2000; // Giới hạn để chừa chỗ cho các phần khác

async function initializeFiles() {
  try {
    // Tạo .env nếu chưa tồn tại
    try {
      await fs.access(ENV_FILE);
    } catch (error) {
      await fs.writeFile(ENV_FILE, 'DISCORD_TOKEN=your_discord_bot_token\nGROQ_API_KEY=your_groq_api_key\nGEMINI_API_KEY=your_gemini_api_key\nDISCORD_CLIENT_ID=your_discord_client_id');
      console.log(formatLogMessage('INFO', `🌱 Đã tạo file .env với nội dung mặc định. Vui lòng cập nhật các giá trị API key!`));
    }

    // Tạo config.json nếu chưa tồn tại
    try {
      await fs.access(CONFIG_FILE);
    } catch (error) {
      await fs.writeFile(CONFIG_FILE, JSON.stringify({
        translateChannelId: null,
        logChannelId: null,
        codeChannelId: null,
        skinChannelId: null,
        skinLogChannelId: null,
        enabledPlugins: {}
      }, null, 2));
      console.log(formatLogMessage('INFO', `📝 Đã tạo file config.json với nội dung mặc định.`));
    }

    // Tạo thư mục plugins nếu chưa tồn tại
    try {
      await fs.access(PLUGINS_DIR);
    } catch (error) {
      await fs.mkdir(PLUGINS_DIR);
      console.log(formatLogMessage('INFO', `📂 Đã tạo thư mục plugins.`));
    }

    // Tạo test.txt nếu chưa tồn tại
    try {
      await fs.access(TEST_FILE_PATH);
    } catch (error) {
      await fs.writeFile(TEST_FILE_PATH, 'Đây là file test để kiểm tra hoạt động của bot.');
      console.log(formatLogMessage('INFO', `📄 Đã tạo file test.txt.`));
    }
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi khi khởi tạo file: ${error.message}`));
  }
}

async function loadConfig() {
  try {
    const data = await fs.readFile(CONFIG_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi khi đọc config.json: ${error.message}`));
    return { translateChannelId: null, logChannelId: null, codeChannelId: null, skinChannelId: null, skinLogChannelId: null, enabledPlugins: {} };
  }
}

async function saveConfig(config) {
  try {
    await fs.writeFile(CONFIG_FILE, JSON.stringify(config, null, 2));
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi khi ghi config.json: ${error.message}`));
  }
}

function formatLogMessage(level, message) {
  const now = new Date();
  const time = now.toLocaleTimeString('en-GB', { hour12: false });
  return `[${time}] [${level}] ${message}`;
}

async function loadPlugins() {
  try {
    await fs.access(PLUGINS_DIR);
  } catch (error) {
    await fs.mkdir(PLUGINS_DIR);
  }
  const plugins = {};
  const failedPlugins = [];
  const files = await fs.readdir(PLUGINS_DIR);
  for (const file of files) {
    if (file.endsWith('.js')) {
      try {
        const pluginPath = path.join(PLUGINS_DIR, file);
        delete require.cache[require.resolve(pluginPath)]; // Xóa cache để reload plugin
        const plugin = require(pluginPath);
        if (plugin.data && typeof plugin.data === 'object' && plugin.data.name) {
          plugins[plugin.data.name] = plugin;
          console.log(formatLogMessage('INFO', `✅ Đã load plugin: ${file} (Lệnh: /${plugin.data.name})`));
        } else {
          failedPlugins.push({ name: file, reason: 'Thiếu hoặc định dạng dữ liệu plugin không hợp lệ' });
        }
      } catch (error) {
        failedPlugins.push({ name: file, reason: `Lỗi khi load: ${error.message}` });
        console.error(formatLogMessage('ERROR', `🚫 Lỗi khi load plugin ${file}: ${error.message}`));
      }
    }
  }
  return { plugins, failedPlugins };
}

async function registerCommands(plugins) {
  if (!process.env.DISCORD_TOKEN || !process.env.DISCORD_CLIENT_ID) {
    console.error(formatLogMessage('ERROR', `🚫 Thiếu DISCORD_TOKEN hoặc DISCORD_CLIENT_ID trong file .env!`));
    return;
  }

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  const commands = [
    new SlashCommandBuilder()
      .setName('setup_translate')
      .setDescription('Thiết lập kênh để upload file cần dịch 🎉')
      .addChannelOption(option =>
        option.setName('channel')
          .setDescription('Kênh để upload file cần dịch 🌟')
          .setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder()
      .setName('setup_log')
      .setDescription('Thiết lập kênh để ghi log 📝')
      .addChannelOption(option =>
        option.setName('channel')
          .setDescription('Kênh để ghi log 📌')
          .setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder()
      .setName('setup_code')
      .setDescription('Thiết lập kênh để viết code 💻')
      .addChannelOption(option =>
        option.setName('channel')
          .setDescription('Kênh để viết code 🖥️')
          .setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder()
      .setName('toggle_plugin')
      .setDescription('Bật/tắt plugin cho toàn bộ kênh 🔧')
      .addStringOption(option =>
        option.setName('plugin')
          .setDescription('Tên plugin để bật/tắt ⚙️')
          .setRequired(true))
      .addBooleanOption(option =>
        option.setName('state')
          .setDescription('Trạng thái bật (true) hoặc tắt (false) 🎚️')
          .setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder()
      .setName('test')
      .setDescription('Kiểm tra hoạt động của bot bằng cách gửi file test ✅')
  ];

  // Thêm lệnh từ các plugin
  const pluginCommands = [];
  for (const pluginName in plugins) {
    const plugin = plugins[pluginName];
    if (plugin.data) {
      try {
        commands.push(plugin.data);
        pluginCommands.push(`/ ${plugin.data.name}`);
        console.log(formatLogMessage('INFO', `🌟 Đã thêm lệnh từ plugin ${pluginName}: /${plugin.data.name}`));
      } catch (error) {
        console.error(formatLogMessage('ERROR', `🚫 Lỗi khi thêm lệnh từ plugin ${pluginName}: ${error.message}`));
      }
    }
  }

  try {
    console.log(formatLogMessage('INFO', `Đang đăng ký ${commands.length} lệnh slash với Discord... 🌐`));
    await rest.put(
      Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
      { body: commands.map(command => command.toJSON()) }
    );
    console.log(formatLogMessage('INFO', `✅ Đã đăng ký ${commands.length} lệnh slash thành công: ${commands.map(c => c.name).join(', ')}`));
    await logToChannel(`✅ Đã đăng ký ${commands.length} lệnh slash: ${commands.map(c => c.name).join(', ')}` + (pluginCommands.length > 0 ? `\n🌟 Bao gồm các lệnh plugin: ${pluginCommands.join(', ')}` : ''));
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi khi đăng ký lệnh: ${error.message}`));
    if (error.rawError) {
      console.error(formatLogMessage('ERROR', `Chi tiết lỗi: ⚠️ ${JSON.stringify(error.rawError, null, 2)}`));
    }
    await logToChannel(`🚫 Lỗi khi đăng ký lệnh: ${error.message}`);
  }
}

async function translateTextWithGroq(text) {
  try {
    const response = await groq.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Bạn là một trợ lý dịch thuật chuyên nghiệp. Dịch văn bản sang tiếng Việt một cách chính xác và tự nhiên. 🌍'
        },
        {
          role: 'user',
          content: `Dịch sang tiếng Việt: ${text}`
        }
      ],
      model: 'llama-3.1-8b-instant'
    });
    return response.choices[0].message.content;
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi Groq: ${error.message}`));
    throw error;
  }
}

async function translateContent(content, fileType) {
  if (fileType === '.yml' || fileType === '.yaml') {
    try {
      const yamlObj = yaml.load(content);
      const translateNested = async (obj) => {
        if (typeof obj === 'string') {
          return await translateTextWithGroq(obj);
        } else if (typeof obj === 'object' && obj !== null) {
          const translatedObj = Array.isArray(obj) ? [] : {};
          for (const key in obj) {
            translatedObj[key] = await translateNested(obj[key]);
          }
          return translatedObj;
        }
        return obj;
      };
      const translatedObj = await translateNested(yamlObj);
      return yaml.dump(translatedObj);
    } catch (error) {
      throw new Error(`Lỗi xử lý YAML: 🚨 ${error.message}`);
    }
  } else if (fileType === '.json') {
    try {
      const jsonObj = JSON.parse(content);
      const translateNested = async (obj) => {
        if (typeof obj === 'string') {
          return await translateTextWithGroq(obj);
        } else if (typeof obj === 'object' && obj !== null) {
          const translatedObj = Array.isArray(obj) ? [] : {};
          for (const key in obj) {
            translatedObj[key] = await translateNested(obj[key]);
          }
          return translatedObj;
        }
        return obj;
      };
      const translatedObj = await translateNested(jsonObj);
      return JSON.stringify(translatedObj, null, 2);
    } catch (error) {
      throw new Error(`Lỗi xử lý JSON: 🚨 ${error.message}`);
    }
  } else if (fileType === '.csv' || fileType === '.txt') {
    return await translateLargeText(content);
  }
  return content;
}

async function translateLargeText(text) {
  if (text.length > MAX_CONTENT_LENGTH) {
    const chunks = [];
    for (let i = 0; i < text.length; i += CHUNK_SIZE) {
      chunks.push(text.slice(i, i + CHUNK_SIZE));
    }
    const translatedChunks = await Promise.all(chunks.map(chunk => translateTextWithGroq(chunk)));
    return translatedChunks.join('');
  }
  return await translateTextWithGroq(text);
}

async function generateCodeWithGemini(prompt, fileContent = '') {
  try {
    let fullPrompt = fileContent ? `${prompt}\nFile context:\n${fileContent}` : prompt;
    if (fullPrompt.length > MAX_PROMPT_LENGTH) {
      fullPrompt = fullPrompt.slice(0, MAX_PROMPT_LENGTH) + '... [Nội dung bị cắt ngắn do vượt quá giới hạn 2000 ký tự]';
    }

    const response = await axios.post(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + process.env.GEMINI_API_KEY,
      {
        contents: [{
          parts: [{
            text: fullPrompt
          }]
        }]
      },
      {
        headers: { 'Content-Type': 'application/json' },
        timeout: 100000
      }
    );
    if (response.data.error) throw new Error(response.data.error.message);
    return response.data.candidates[0].content.parts[0].text || 'Không tạo được code.';
  } catch (error) {
    console.error(formatLogMessage('ERROR', `🚫 Lỗi Gemini: ${error.response?.data || error.message}`));
    throw new Error(`Lỗi khi tạo code: 🚨 ${error.response?.data?.error?.message || error.message}`);
  }
}

async function prepareTestFile() {
  try {
    await fs.access(TEST_FILE_PATH);
  } catch (error) {
    await fs.writeFile(TEST_FILE_PATH, 'Đây là file test để kiểm tra hoạt động của bot.');
  }
}

async function logToChannel(message) {
  const config = await loadConfig();
  const logChannel = client.channels.cache.get(config.logChannelId || config.skinLogChannelId);
  if (logChannel) {
    await logChannel.send(formatLogMessage('INFO', `📝 ${message}`));
  } else {
    console.log(formatLogMessage('INFO', `📝 ${message}`));
  }
}

client.on('ready', async () => {
  console.log(formatLogMessage('INFO', `Bot đã đăng nhập với tên ${client.user.tag}! 🎉`));
  await initializeFiles();
  const { plugins, failedPlugins } = await loadPlugins();
  client.plugins = plugins;
  const config = await loadConfig();
  if (Object.keys(client.plugins).length > 0) {
    const allChannels = [config.translateChannelId, config.logChannelId, config.codeChannelId, config.skinChannelId, config.skinLogChannelId].filter(id => id);
    for (const pluginName in client.plugins) {
      if (!config.enabledPlugins[pluginName]) {
        config.enabledPlugins[pluginName] = true;
        await logToChannel(`🌟 Plugin ${pluginName} đã được bật mặc định cho toàn bộ kênh bởi hệ thống.`);
      }
    }
    await saveConfig(config);
  }
  await registerCommands(client.plugins);
  const successCount = Object.keys(client.plugins).length;
  const failedCount = failedPlugins.length;
  let startupMessage = `✅ Bot đã khởi động thành công với tên ${client.user.tag}!\n`;
  startupMessage += `🎉 Đã load ${successCount} plugin thành công: ${Object.keys(client.plugins).join(', ')}`;
  if (failedCount > 0) {
    startupMessage += `\n🚫 Không load được ${failedCount} plugin: ${failedPlugins.map(p => `${p.name} (${p.reason})`).join(', ')}`;
  }
  await logToChannel(startupMessage);
  if (!config.translateChannelId || !config.logChannelId || !config.codeChannelId) {
    console.log(formatLogMessage('WARN', `⚠️ Chưa thiết lập đầy đủ kênh, vui lòng dùng /setup_translate, /setup_log, và /setup_code.`));
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;

  try {
    if (commandName === 'setup_translate') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        await interaction.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng lệnh này!', ephemeral: true });
        return;
      }
      const channel = interaction.options.getChannel('channel');
      const config = await loadConfig();
      config.translateChannelId = channel.id;
      await saveConfig(config);
      await interaction.reply(`✅ Đã thiết lập kênh dịch: ${channel.name} 🎉`);
      await logToChannel(`🌟 Đã thiết lập kênh dịch: ${channel.name} bởi ${interaction.user.tag}`);
    } else if (commandName === 'setup_log') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        await interaction.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng lệnh này!', ephemeral: true });
        return;
      }
      const channel = interaction.options.getChannel('channel');
      const config = await loadConfig();
      config.logChannelId = channel.id;
      await saveConfig(config);
      await interaction.reply(`✅ Đã thiết lập kênh log: ${channel.name} 📝`);
      await logToChannel(`🌱 Đã thiết lập kênh log: ${channel.name} bởi ${interaction.user.tag}`);
    } else if (commandName === 'setup_code') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        await interaction.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng lệnh này!', ephemeral: true });
        return;
      }
      const channel = interaction.options.getChannel('channel');
      const config = await loadConfig();
      config.codeChannelId = channel.id;
      await saveConfig(config);
      await interaction.reply(`✅ Đã thiết lập kênh viết code: ${channel.name} 💻`);
      await logToChannel(`🌟 Đã thiết lập kênh viết code: ${channel.name} bởi ${interaction.user.tag}`);
    } else if (commandName === 'toggle_plugin') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        await interaction.reply({ content: '⚠️ Chỉ admin mới có thể sử dụng lệnh này!', ephemeral: true });
        return;
      }
      const pluginName = interaction.options.getString('plugin');
      const state = interaction.options.getBoolean('state');
      const config = await loadConfig();
      if (!client.plugins[pluginName]) {
        await interaction.reply({ content: `🚫 Plugin "${pluginName}" không tồn tại!`, ephemeral: true });
        return;
      }
      config.enabledPlugins[pluginName] = state;
      await saveConfig(config);
      const status = state ? 'bật' : 'tắt';
      await interaction.reply(`✅ Plugin "${pluginName}" đã được ${status} thành công! 🔧`);
      await logToChannel(`🌱 Plugin "${pluginName}" đã được ${status} bởi ${interaction.user.tag}`);
    } else if (commandName === 'test') {
      await interaction.deferReply();
      const config = await loadConfig();
      if (!config.translateChannelId) {
        await interaction.editReply(`🚫 Chưa thiết lập kênh dịch, vui lòng dùng /setup_translate.`);
        return;
      }
      await prepareTestFile();
      const fileStats = await fs.stat(TEST_FILE_PATH);
      const fileSizeKB = (fileStats.size / 1024).toFixed(2);
      await client.channels.cache.get(config.translateChannelId).send({
        content: `🎉🌟 Dịch thành công!\n` +
                 `- Tên file: test.txt 📄\n` +
                 `- 📏 Dung lượng: ${fileSizeKB} KB\n` +
                 `- ⏳ Thời gian: 0.0 giây\n` +
                 `- 👤 Người dùng: @${interaction.user.username}\n` +
                 `Cảm ơn bạn đã sử dụng bot! 🙌`
      });
      await interaction.editReply(`✅ Đã gửi file test.txt để kiểm tra! 🎉`);
      await logToChannel(`🌱 Đã gửi file test.txt để kiểm tra bởi ${interaction.user.tag}`);
    } else {
      const config = await loadConfig();
      if (config.enabledPlugins[commandName] === false) {
        await interaction.reply({ content: `🚫 Plugin ${commandName} hiện đang bị tắt!`, ephemeral: true });
        return;
      }
      const plugin = client.plugins[commandName];
      if (plugin) {
        try {
          await plugin.execute(interaction, { loadConfig, saveConfig, logToChannel });
          await logToChannel(`🌟 Đã thực thi lệnh /${commandName} ${interaction.options.getSubcommand() || ''} bởi ${interaction.user.tag}`);
        } catch (error) {
          await interaction.reply({ content: `🚫 Đã xảy ra lỗi khi thực thi lệnh ${commandName}!`, ephemeral: true });
          await logToChannel(`⚠️ Lỗi khi thực thi lệnh /${commandName} ${interaction.options.getSubcommand() || ''} bởi ${interaction.user.tag}: ${error.message}`);
        }
      } else {
        await interaction.reply({ content: `🚫 Lệnh ${commandName} không tồn tại hoặc chưa được đăng ký!`, ephemeral: true });
        await logToChannel(`⚠️ Lệnh ${commandName} không tồn tại khi được gọi bởi ${interaction.user.tag}`);
      }
    }
  } catch (error) {
    await interaction.reply({ content: '❌ Lỗi khi xử lý lệnh! Vui lòng thử lại sau. 😢', ephemeral: true });
    await logToChannel(`🚫 Lỗi khi xử lý lệnh /${commandName} bởi ${interaction.user.tag}: ${error.message}`);
  }
});

client.on('messageCreate', async message => {
  if (message.author.id === client.user.id) return;

  const config = await loadConfig();
  const channelId = message.channelId;

  // Xử lý tin nhắn trong kênh skinChannelId cho plugin skinconverter
  if (channelId === config.skinChannelId && config.enabledPlugins['skinconverter'] !== false) {
    const plugin = client.plugins['skinconverter'];
    if (plugin && plugin.handleMessage) {
      try {
        await plugin.handleMessage(message, { loadConfig, saveConfig, logToChannel });
      } catch (error) {
        await logToChannel(`🚫 Lỗi plugin skinconverter trong kênh ${message.channel.name}: ${error.message}`);
      }
    }
  }

  // Xử lý plugin taixiu (nếu có) trong các kênh khác
  if (client.plugins['taixiu'] && config.enabledPlugins['taixiu'] !== false) {
    const plugin = client.plugins['taixiu'];
    try {
      if (message.attachments.size && plugin.handleAttachment) {
        const attachment = message.attachments.first();
        await plugin.handleAttachment(message, attachment);
      } else if (message.content && plugin.handleMessage) {
        await plugin.handleMessage(message, { loadConfig, saveConfig, logToChannel });
      }
    } catch (error) {
      await logToChannel(`🚫 Lỗi plugin taixiu trong kênh ${message.channel.name}: ${error.message}`);
    }
  }

  // Xử lý file đính kèm trong kênh translateChannelId
  if (channelId === config.translateChannelId && message.attachments.size) {
    const attachment = message.attachments.first();
    const fileExt = path.extname(attachment.name).toLowerCase();
    const supportedExtensions = ['.yml', '.yaml', '.json', '.csv', '.txt'];
    if (!supportedExtensions.includes(fileExt)) {
      await message.reply(`🚫 Vui lòng upload file có định dạng: ${supportedExtensions.join(', ')}.`);
      await logToChannel(`⚠️ Lỗi: File không hỗ trợ - ${attachment.name} bởi ${message.author.tag}`);
      return;
    }

    try {
      const response = await fetch(attachment.url);
      const content = await response.text();
      const originalFilePath = path.join(__dirname, `original_${attachment.name}`);
      await fs.writeFile(originalFilePath, content);

      const startTime = Date.now();
      let translatedContent;
      try {
        translatedContent = await translateContent(content, fileExt);
      } catch (error) {
        await message.reply('🚫 Đã xảy ra lỗi khi dịch file.');
        await logToChannel(`⚠️ Lỗi khi dịch file ${attachment.name} bởi ${message.author.tag}: ${error.message}`);
        translatedContent = await translateLargeText(content);
      }
      const endTime = Date.now();
      const translationTime = ((endTime - startTime) / 1000).toFixed(1);

      if (!translatedContent) {
        await message.reply('🚫 Đã xảy ra lỗi khi dịch file sau khi chia nhỏ.');
        await logToChannel(`⚠️ Lỗi khi dịch file ${attachment.name} sau khi chia nhỏ bởi ${message.author.tag}: Không thể dịch nội dung.`);
        await fs.unlink(originalFilePath).catch(() => {});
        return;
      }

      const translatedFilePath = path.join(__dirname, attachment.name);
      await fs.writeFile(translatedFilePath, translatedContent);
      const fileStats = await fs.stat(translatedFilePath);
      const fileSizeKB = (fileStats.size / 1024).toFixed(2);

      await message.reply({
        content: `🎉🌟 File đã dịch thành công! 📥`,
        files: [translatedFilePath]
      });
      await logToChannel(`🌱 Đã dịch file: ${attachment.name} bởi ${message.author.tag}`);
      await fs.unlink(originalFilePath).catch(() => {});
      await fs.unlink(translatedFilePath).catch(() => {});
    } catch (error) {
      await message.reply('🚫 Đã xảy ra lỗi khi xử lý file.');
      await logToChannel(`⚠️ Lỗi khi xử lý file ${attachment.name} bởi ${message.author.tag}: ${error.message}`);
      await fs.unlink(path.join(__dirname, `original_${attachment.name}`)).catch(() => {});
    }
  }

  // Xử lý file hoặc tin nhắn trong kênh codeChannelId
  if (channelId === config.codeChannelId && message.attachments.size) {
    const attachment = message.attachments.first();
    const fileExt = path.extname(attachment.name).toLowerCase();
    const supportedCodeExtensions = ['.py', '.js', '.cpp', '.java', '.txt'];
    if (!supportedCodeExtensions.includes(fileExt)) {
      await message.reply(`🚫 Vui lòng upload file code có định dạng: ${supportedCodeExtensions.join(', ')}.`);
      await logToChannel(`⚠️ Lỗi: File code không hỗ trợ - ${attachment.name} bởi ${message.author.tag}`);
      return;
    }

    try {
      const response = await fetch(attachment.url);
      const fileContent = await response.text();
      const prompt = message.content || 'Viết code dựa trên file đã upload.';
      const code = await generateCodeWithGemini(prompt, fileContent);
      const codeFilePath = path.join(__dirname, `generated_${Date.now()}.${fileExt}`);
      await fs.writeFile(codeFilePath, code);

      await message.reply({
        content: `🎉🌟 Code đã sẵn sàng! 💻`,
        files: [codeFilePath]
      });
      await logToChannel(`🌱 Đã tạo code từ file ${attachment.name} bởi ${message.author.tag}`);
      await fs.unlink(codeFilePath).catch(() => {});
    } catch (error) {
      await message.reply('🚫 Đã xảy ra lỗi khi tạo code.');
      await logToChannel(`⚠️ Lỗi khi tạo code từ file ${attachment.name} bởi ${message.author.tag}: ${error.message}`);
    }
  } else if (channelId === config.codeChannelId && !message.attachments.size && message.content) {
    try {
      const code = await generateCodeWithGemini(message.content);
      const codeFilePath = path.join(__dirname, `generated_${Date.now()}.txt`);
      await fs.writeFile(codeFilePath, code);

      await message.reply({
        content: `🎉🌟 Code đã sẵn sàng! 💻`,
        files: [codeFilePath]
      });
      await logToChannel(`🌱 Đã tạo code từ prompt bởi ${message.author.tag}`);
      await fs.unlink(codeFilePath).catch(() => {});
    } catch (error) {
      await message.reply('🚫 Đã xảy ra lỗi khi tạo code.');
      await logToChannel(`⚠️ Lỗi khi tạo code từ prompt bởi ${message.author.tag}: ${error.message}`);
    }
  }
});

client.login(process.env.DISCORD_TOKEN);